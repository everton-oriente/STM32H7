#include "MPU6050.h"

extern I2C_HandleTypeDef hi2c1;

float Ax, Ay, Az;
float Gx, Gy, Gz;

static void MPU6050_Write(uint8_t address, uint8_t data)
{
    uint8_t buffer[2];
    buffer[0] = address;
    buffer[1] = data;
    HAL_I2C_Master_Transmit(&hi2c1, MPU6050_ADDR, buffer, 2, HAL_MAX_DELAY);
}

static void MPU6050_Read(uint8_t address, uint8_t *data, uint16_t size)
{
    HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, address, 1, data, size, HAL_MAX_DELAY);
}

void MPU6050_Init(void)
{
    uint8_t check;
    uint8_t data;

    // Check device ID WHO_AM_I
    MPU6050_Read(0x75, &check, 1);
    if (check == 0x68)  // 0x68 will be returned by the sensor if everything goes well
    {
        // Power management register: write all 0's to wake the sensor up
        data = 0;
        MPU6050_Write(MPU6050_PWR_MGMT_1, data);

        // Set DATA RATE of 1KHz by writing SMPLRT_DIV register
        data = 0x07;
        MPU6050_Write(0x19, data);

        // Set accelerometer configuration in ACCEL_CONFIG Register
        // XA_ST=0, YA_ST=0, ZA_ST=0, AFS_SEL=0 -> ±2g
        data = 0x00;
        MPU6050_Write(0x1C, data);

        // Set gyroscope configuration in GYRO_CONFIG Register
        // XG_ST=0, YG_ST=0, ZG_ST=0, FS_SEL=0 -> ±250 °/s
        data = 0x00;
        MPU6050_Write(0x1B, data);
    }
}

void MPU6050_Read_Accel(void)
{
    uint8_t data[6];
    int16_t ax, ay, az;

    MPU6050_Read(MPU6050_ACCEL_XOUT_H, data, 6);

    ax = (int16_t)(data[0] << 8 | data[1]);
    ay = (int16_t)(data[2] << 8 | data[3]);
    az = (int16_t)(data[4] << 8 | data[5]);

    Ax = ax / 16384.0; // Convert to g
    Ay = ay / 16384.0;
    Az = az / 16384.0;
}

void MPU6050_Read_Gyro(void)
{
    uint8_t data[6];
    int16_t gx, gy, gz;

    MPU6050_Read(MPU6050_GYRO_XOUT_H, data, 6);

    gx = (int16_t)(data[0] << 8 | data[1]);
    gy = (int16_t)(data[2] << 8 | data[3]);
    gz = (int16_t)(data[4] << 8 | data[5]);

    Gx = gx / 131.0; // Convert to °/s
    Gy = gy / 131.0;
    Gz = gz / 131.0;
}
